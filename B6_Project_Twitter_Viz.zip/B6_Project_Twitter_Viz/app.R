#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(igraph)
library(network)
library(sna)
library(network)
library(RColorBrewer)
library(networkD3)
library(wordcloud)
library(tm)
library(SnowballC)

# Define UI for application that draws a histogram
ui <- shinyUI(navbarPage("#Tag-@Mention Visualizations",
                         colorSet <- c("Blues", "BuGn", "BuPu", "GnBu", "Greens", "Greys", "Oranges", "OrRd", "PuBu", "PuBuGn", "PuRd", "Purples", "RdPu", "Reds",
                                       "YlGn", "YlGnBu", "YlOrBr", "YlOrRd"),
                         tabPanel("WordCloud",
                                  
                                  #THIS IS THE SIDEBAR INPUT PANEL
                                  column(2,wellPanel(
                                    
                                    checkboxInput("checkbox3", label = "Document stemming", value = TRUE),
                                    checkboxInput("checkbox2", label = "Repeatable", value = TRUE),
                                    
                                    # Slider input for minimum frequency
                                    sliderInput("slider4", "Minimum Frequency:",
                                                min = 0.0, max = 500, value = 50),
                                    
                                    # Slider input for rotation change
                                    sliderInput("slider3", "Rotation:",
                                                min = 0.0, max = 1.0, value = 0.35),
                                    
                                    # Slider input for number of words change
                                    sliderInput("slider2", "Maximum Words:",
                                                min = 10, max = 1000, value = 100),
                                    
                                    # Text file uploader
                                    fileInput("file", "Text file", accept=c("text/plain", ".txt"))
                                    
                                  )),
                                  
                                  #THIS IS THE MAIN CONTENT
                                  column(10, 
                                         # Image download button
                                         downloadButton("wordcloud_img", "Download Image"),
                                         # CSV download button
                                         downloadButton("freq_csv", "Download Frequency Table"),
                                         # Wordcloud image rendered
                                         imageOutput("wordcloud")

                                        )#end of main body columns 
                         ) #end tab panel
                         
                         ,
                         tabPanel("Network Graph",
                                  
                                  column(2,wellPanel(
                                    
                                  sliderInput("node_repulsion", "Node Repulsion:", 
                                              min = 10, max = 500, 
                                              value = 10),
                                  
                                  sliderInput('link_distance', "Link Distance", 
                                              min=5, max=300,
                                              value=30, 
                                              step=5),
                                  
                                  sliderInput('font_size', "Font Size", 
                                              min=5, max=50,
                                              value=10, 
                                              step=2),
                                  
                                  selectInput('node_color', "Node Color", 
                                              colorSet,
                                              selected="YlGnBu"),
                                  
                                  selectInput('selected_hash', "Select #Tag", "")
                                  # colorSet,
                                  # selected="YlGnBu")
                                  
                                  )),
                                  
                                  column(10,
                                         
                                         forceNetworkOutput("forceNet1"),
                                         forceNetworkOutput("forceNet2")
                                  )
                                  

                         )
                         # ,
                         # navbarMenu("More Info",
                         #            tabPanel("Test1",
                         #                     dataTableOutput("table")
                         #            )
                         # )
  ))
  

# Define server logic required to draw a histogram
server <- shinyServer(function(input, output, session) {

  linksFileLocation <-  paste0(getwd(),"/Twitter_Eng_Hash_UserMention_Unique_6.csv")
  nodesFileLocation <- paste0(getwd(),"/Unique hash-mention_6.csv")
  
  links <- read.csv(linksFileLocation, header = T, as.is = T)
  nodes <- read.csv(nodesFileLocation, header = T, as.is = T)
  
  # links <- read.csv("C:/R_Files/Polnet2015/Data/Twitter_Eng_Hash_UserMention_Unique_6.csv", header = T, as.is = T)
  # nodes <- read.csv("C:/R_Files/Polnet2015/Data/Unique hash-mention_6.csv", header = T, as.is = T)
  # 
  
  observe({
    updateSelectInput(session, "selected_hash", choices = unique(links$FROM) )
  })

  
  output$forceNet1 <- renderForceNetwork({
    
    vertices<-data.frame(name = nodes$id, group = nodes$TYPE,stringsAsFactors=F  ) 
    
    links$value <-(links$Weight/sum(links$Weight))*500
    links$FROM.index = match(links$FROM, vertices$name)-1
    links$TO.index = match(links$TO, vertices$name)-1

    scalecolors <- function(nodes, palette) {
      n <- max(unique(vertices$group))
      cols <- rev(RColorBrewer::brewer.pal(n, palette))
      cols <- paste0("'", paste(cols, collapse = "', '"), "'")
      networkD3::JS(paste0('d3.scale.ordinal().domain([0,', n, ']).range([', cols, '])'))
    }
        
    forceNetwork(Links = links, Nodes = vertices,
                 Source = 'FROM.index', 
                 Target = 'TO.index',
                 NodeID = 'name', 
                 Value = "value",
                 Group = 'group',
                 charge = -input$node_repulsion,
                 colourScale = scalecolors(vertices, input$node_color),
                 #linkColour = "#fff",
                 linkDistance = input$link_distance,
                 zoom = T, 
                 opacity = 2,
                 fontSize=input$font_size
                 ,height = 3800
                 )     
  })
  
  output$forceNet2 <- renderForceNetwork({
    
    if(is.null(input$selected_hash)){
      hash <- "#uselection"
    }else{
      hash <- input$selected_hash
    }
    
    n2<-"1"
    l<-links[links$FROM==hash,]
    x2<-data.frame(c(l$FROM,l$TO),n2,stringsAsFactors=F)
    names(x2)<-c("id","TYPE")
    
    x2$TYPE[substr(x2$id,1,1)=="@"]<-2
    
    vertices<-data.frame(name = unique(x2)$id, group = unique(x2)$TYPE,stringsAsFactors=F ) 
    
    l$value <-(l$Weight/sum(l$Weight))*500
    l$FROM.index = match(l$FROM, vertices$name)-1
    l$TO.index = match(l$TO, vertices$name)-1
    
    scalecolors2 <- function(nodes, palette) {
      n <- max(unique(vertices$group))
      cols <- rev(RColorBrewer::brewer.pal(n, palette))
      cols <- paste0("'", paste(cols, collapse = "', '"), "'")
      networkD3::JS(paste0('d3.scale.ordinal().domain([0,', n, ']).range([', cols, '])'))
    }
    
    forceNetwork(Links = l, Nodes = vertices,
                 Source = 'FROM.index', 
                 Target = 'TO.index',
                 NodeID = 'name', 
                 Value = "value",
                 Group = 'group',
                 # charge = -input$node_repulsion,
                 #colourScale = scalecolors2(vertices, input$node_color),
                 # #linkColour = "#fff",
                 # linkDistance = input$link_distance,
                 zoom = T, 
                 opacity = 2,
                 fontSize=15  #input$font_size
    )     
  })
  
  
 ##################################################### 
  
  
  datainput <- reactive({
    
    # Outputs a helpful message when no text file is uploaded
    validate(
      need((input$text != "") || (!is.null(input$file)),
           "Please upload a text file."
      )
    )
    
    # Load text from text file uploaded
    if (!is.null(input$file)){
      a <- input$file$datapath
      a <- substr(a, 1, nchar(a) - 1)
      words <- Corpus(DirSource(a))
    }
    
    # Remove all punctuations except hashtag
    removeMostPunctuation<-
      function (x, preserve_intra_word_dashes = FALSE)
      {
        rmpunct <- function(x) {
          #x <- gsub("#","\002", x)
          x <- gsub("[]\\?!\"\'$%&(){}+*/:;,._`|~\\[<=>\\^-]", "", x)
          #gsub("\002", "#", x, fixed = TRUE)
        }
        if (preserve_intra_word_dashes) {
          x <- gsub("(\\w)-(\\w)", "\\1\001\\2", x)
          x <- rmpunct(x)
          gsub("\001", "-", x, fixed = TRUE)
        } else {
          rmpunct(x)
        }
      }
    
    
    # Cleaning & normalizing the corpus.
    words <- tm_map(words, content_transformer(removeMostPunctuation),
                    preserve_intra_word_dashes = TRUE)
    words <- tm_map(words, removeNumbers)
    words <- tm_map(words, removeWords, c(stopwords("en"),"the","amp","httpstcoxzuewsek"))
    words <- tm_map(words, stripWhitespace)
    
  })
  
  # Reactive element to transform the data on the basis of
  # (de)selection of checkbox3 in ui.R
  finalinput <- reactive({
    if (input$checkbox3) datainput <- tm_map(datainput(), stemDocument)
    datainput()
  })
  
  # Reactive element to transform the data on the basis of
  # (de)selection of checkbox2 in ui.R
  asdas <- reactive({
    if (input$checkbox2) wordcloud_rep <- repeatable(wordcloud)
    else wordcloud_rep <- wordcloud
  })
  
  # Reactive element to generate the wordcloud and save it as a png
  # and return the filename.
  make_cloud <- reactive ({
    wordcloud_rep <- asdas()
    
    png("wordcloud.png", width=10, height=8, units="in", res=350)
    w <- wordcloud_rep(finalinput(),
                       scale=c(5, 0.5),
                       min.freq=input$slider4,
                       max.words=input$slider2,
                       rot.per=input$slider3,
                       use.r.layout=FALSE,
                       colors=brewer.pal(8, "Dark2"))
    dev.off()
    
    filename <- "wordcloud.png"
  })
  
  # Download handler for the image.
  output$wordcloud_img <- downloadHandler(
    filename = "wordcloud.png",
    content = function(cloud) {
      file.copy(make_cloud(), cloud)
    })
  
  # Download handler for the csv.
  output$freq_csv <- downloadHandler(
    filename = "freq.csv",
    content = function(freq) {
      a <- DocumentTermMatrix(finalinput())
      b <- sort(colSums(as.matrix(a)), decreasing=TRUE)
      write.csv(b, freq)
    })
  
  # Sending the wordcloud image to be rendered.
  output$wordcloud <- renderImage({
    list(src=make_cloud(), alt="Image being generated!", height=600)
  },
  deleteFile = FALSE)
#########################################################################################################
  

})

# Run the application 
shinyApp(ui = ui, server = server)

